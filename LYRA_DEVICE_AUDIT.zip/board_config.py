"""Central configuration for the Lyra Pulse ESP32 fingerprint attendance device."""

# ------------------------------------------------------------
# Wi-Fi
# ------------------------------------------------------------
# Use a 2.4 GHz Wi-Fi network; ESP32 does not support 5 GHz.
# Replace these with your real values before flashing to a device.
# WIFI_SSID = "Airtel_vasa_3220"
# WIFI_PASSWORD = "Air@69764"
# WIFI_TIMEOUT_SECONDS = 20
# WIFI_RETRY_COUNT = 3

# WIFI_SSID = "TP-Link_9BAF"
# WIFI_PASSWORD = "44639518"
# WIFI_TIMEOUT_SECONDS = 20
# WIFI_RETRY_COUNT = 3


WIFI_SSID = "Personal"
WIFI_PASSWORD = "12345678"
WIFI_TIMEOUT_SECONDS = 20
WIFI_RETRY_COUNT = 3
    
# ------------------------------------------------------------
# Device identity
# ------------------------------------------------------------
DEVICE_ID = "LYRA-DEVICE-001"
DEVICE_TOKEN = "1WCnPgVGKZH80X1Pz33JXs8z8dfIqFwbDIGjAgB8o3M"
TEST_MODE = True

# ------------------------------------------------------------
# API
# ------------------------------------------------------------
# Update to the actual Django backend URL before deployment.
API_BASE_URL = "http://192.168.226.139:8000"
API_FINGERPRINT_ENDPOINT = "/api/v1/attendance/fingerprint/"
API_DEVICE_ENROLLMENT_PENDING = "/api/v1/devices/{device_id}/enrollment/pending/"
API_DEVICE_ENROLLMENT_RESULT = "/api/v1/devices/{device_id}/enrollment/{enrollment_id}/result/"
API_TIMEOUT = 10
API_RETRY_COUNT = 2

# ------------------------------------------------------------
# UART fingerprint sensor
# ------------------------------------------------------------
UART_ID = 2
UART_BAUDRATE = 57600
UART_TX_PIN = 17
UART_RX_PIN = 16
R307_ADDRESS = 0xFFFFFFFF
R307_UART_READ_TIMEOUT_MS = 10
R307_DEBUG = True
R307_TOUCH_PIN = 18
R307_TOUCH_ACTIVE_LEVEL = 0
R307_TOUCH_DEBOUNCE_SAMPLES = 11
R307_TOUCH_SAMPLE_INTERVAL_SECONDS = 0.01
R307_DETECTION_MODE = "gpio_only"
R307_UART_FALLBACK_ENABLED = False
R307_UART_FALLBACK_INTERVAL_SECONDS = 2.0
R307_TOUCH_CAPTURE_RETRY_INTERVAL_SECONDS = 0.08
R307_TOUCH_CAPTURE_TIMEOUT_SECONDS = 10
R307_TOUCH_CAPTURE_MAX_ATTEMPTS = 40
R307_FINGER_REMOVAL_TIMEOUT_SECONDS = 30
R307_FINGER_REMOVAL_COOLDOWN_SECONDS = 30
R307_DIAGNOSTIC_MODE = "sensor"
R307_LOOPBACK_CONFIRMED_DISCONNECTED = False
R307_PASSWORD = 0x00000000
ENROLLMENT_TEMPLATE_ID = 1

# ------------------------------------------------------------
# OLED display
# ------------------------------------------------------------
OLED_SDA_PIN = 21
OLED_SCL_PIN = 22
OLED_I2C_ADDRESS = 0x3C

# ------------------------------------------------------------
# GPIO outputs
# ------------------------------------------------------------
BUZZER_PIN = 4
GREEN_LED_PIN = 32
BLUE_LED_PIN = 33
RED_LED_PIN = 25

# ------------------------------------------------------------
# Behavior and safety
# ------------------------------------------------------------
FINGERPRINT_COOLDOWN = 5
FINGER_REMOVAL_SETTLE_SECONDS = 1
MAX_TEMPLATE_COUNT = 1000
ENROLLMENT_STEP_TIMEOUT_SECONDS = 30

# Linux / ESP32 serial configuration for MicroPython development
SERIAL_PORT = "/dev/cu.usbserial-5B150103211"

# ------------------------------------------------------------
# Optional: ensure no sensitive data is ever printed in logs
# ------------------------------------------------------------
def safe_config_summary():
    return {
        "device_id": DEVICE_ID,
        "wifi_ssid": "***configured***",
        "api_base_url": API_BASE_URL,
        "test_mode": TEST_MODE,
    }
